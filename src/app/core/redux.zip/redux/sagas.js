// Import feature sagas to be included with application startup
// import { userSagas } from '~/features/login/redux/sagas';

// const featureSagas = [...userSagas];

const featureSagas = [];

export default [...featureSagas];
