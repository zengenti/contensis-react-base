// Import feature reducers to be included with application startup
// import userReducer from '~/features/login/redux/reducers';

// const featureReducers = { user: userReducer };

const featureReducers = {};

export default { ...featureReducers };
